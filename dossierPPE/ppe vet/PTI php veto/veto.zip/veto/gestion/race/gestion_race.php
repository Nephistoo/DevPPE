﻿<?php

	require_once '../../utilities/secure.php';
	require_once '../../utilities/connect_db.php';
	
	if(!isset($_GET['action']))
	{
		header('Location: /veto/gestion/race/index.php');
	}
	else
	{
		$action = $_GET['action'];
		
		if($action == 'ajout' || ($action == 'modif' && isset($_GET['id'])))
		{				
			if($action == 'modif')
			{
				$id = $_GET['id'];
				$sql = mysql_query('SELECT numr FROM race WHERE numr = "'.$id.'"');
				$nb = mysql_num_rows($sql);
			}
			else
			{
				$id = ''; 
				$nb = 1;
			}
			
			if($nb == 0) // on vérifie si l'id existe bien dans la table
			{
				header('Location: /veto/gestion/race/index.php');
			}
			else
			{
				require_once '../../utilities/top.php';			
			
				echo '<div id="content">';
			
				if($action == 'ajout') {$text = 'Ajout';}else{$text = 'Modification';}
			
				echo '<h1>'.$text.' d\'une race</h1>';
			
				echo '<div id="text">';
			
				if($action == 'modif') 
				{
					$sql = mysql_query('SELECT nomr, poids FROM race WHERE numr = '.$id);
					$res = mysql_fetch_object($sql);
					$nom = $res->nomr;
					$poids = $res->poids;
				}
				else
				{
					$nom = '';
					$poids = '';
				}
			
				echo '<form action="action_race.php" method="POST">';
				echo '<input type="hidden" name="action" value="'.$action.'" />';
				echo '<input type="hidden" name="id" value="'.$id.'" />';
				echo '<table><tbody>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="nom">Nom de la race :</label></td>';
				echo '<td><input type="text" name="nom" value="'.$nom.'"/></td>';
				echo '</tr>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="poids">Poids de la race :&nbsp;</label></td>';
				echo '<td><input type="text" name="poids" value="'.$poids.'" /></td>';
				echo '</tr>';
				
				echo '</tbody></table>';
				echo '<input type="submit" name="Valider" value="Valider"/>';
				echo '</form>';

				echo '</div>'; // fermeture de la div text

				echo '</div>'; // fermeture de la div content
				require_once '../../utilities/footer.php';
			}
		}
		else
		{
				header('Location: /veto/gestion/race/index.php');
		}
	}
?>