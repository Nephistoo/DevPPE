﻿<?php
	
	if($_POST['Valider'] != 'Valider')
	{
		header('Location /veto/gestion/race/index.php');
	}
	else
	{
		$nom = $_POST['nom'];
		$poids = $_POST['poids'];
		if($nom == '' || (!is_numeric($poids) && $poids != ''))
		{
			echo '<script type="text/javascript" language="javascript">alert(\'Veuillez remplir correctement les différents champs !\');document.location.href = "'.$_SERVER['HTTP_REFERER'].'" ;</script>';
		}
		else
		{
			require_once '../../utilities/connect_db.php';
			$action = $_POST['action'];
			$id = $_POST['id'];
			if($action == 'ajout')
			{
				$sql = mysql_query('SELECT numr FROM race WHERE nomr = "'.$nom.'"');
				$nb = mysql_num_rows($sql);
				if($nb != 0)
				{
					echo '<script type="text/javascript" language="javascript">alert(\'Cette race existe déjà !\');document.location.href = "'.$_SERVER['HTTP_REFERER'].'" ;</script>';
				}
				else
				{
					if($poids == '')
					{
						$requete = ', NULL';
					}
					else
					{
						$requete = ', '.$poids;
					}
					
					if(mysql_query('INSERT INTO race (nomr, poids) VALUES ("'.$nom.'" '.$requete.')'))
					{
						echo '<script type="text/javascript" language="javascript">alert(\'Insertion réussie\');document.location.href = "index.php" ;</script>';
					}
					else
					{
						echo '<script type="text/javascript" language="javascript">alert(\'L\'insertion a échouée. Veuillez contacter l\'administrateur du site !\');document.location.href = "index.php" ;</script>';
					}
				}
			}
				
			if($action == 'modif')
			{
				if($poids == '')
				{
					$requete = '';
				}
				else
				{
					$requete = ', poids = '.$poids;
				}
					
				if(mysql_query('UPDATE race SET nomr = "'.$nom.'" '.$requete.' WHERE numr = '.$id))
				{
					echo '<script type="text/javascript" language="javascript">alert(\'Modification réussie\');document.location.href = "index.php" ;</script>';
				}
				else
				{
					echo '<script type="text/javascript" language="javascript">alert(\'La modification a échouée. Veuillez contacter l\'administrateur du site !\');document.location.href = "index.php" ;</script>';
				}
			}
		}
	}
?>