﻿<?php
	require_once '../../utilities/connect_db.php';

	if(!isset($_GET['id']))
	{
		header('Location: /veto/gestion/race/index.php');
	}
	else
	{
		$id = $_GET['id'];
		
		$sql = mysql_query('SELECT numr FROM race WHERE numr = "'.$id.'"');
		$nb = mysql_num_rows($sql);
		
		if($nb == 0)
		{
			header('Location: /veto/gestion/race/index.php');
		}
		else
		{
			$sql = mysql_query('SELECT numa FROM animal WHERE numr = '.$id);
			$nb = mysql_num_rows($sql);
			
			if($nb == 0)
			{	
				$sql_delete = mysql_query('DELETE FROM race WHERE numr = "'.$id.'"');
				header('Location: /veto/gestion/race/index.php');
			}
			else
			{
				echo '<script type="text/javascript" language="javascript">alert(\'Suppression impossible : il existe des animaux associés à cette race !\');document.location.href = "/veto/gestion/race/index.php" ;</script>';
			}
		}
	}




?>