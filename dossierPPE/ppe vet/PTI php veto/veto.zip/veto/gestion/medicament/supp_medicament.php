﻿<?php
	require_once '../../utilities/connect_db.php';

	if(!isset($_GET['id']))
	{
		header('Location: /veto/gestion/medicament/index.php');
	}
	else
	{
		$id = $_GET['id'];
		
		$sql = mysql_query('SELECT numm FROM medicament WHERE numm = "'.$id.'"');
		$nb = mysql_num_rows($sql);
		
		if($nb == 0)
		{
			header('Location: /veto/gestion/medicament/index.php');
		}
		else
		{
			$sql_delete = mysql_query('DELETE FROM medicament WHERE numm = "'.$id.'"');
			header('Location: /veto/gestion/medicament/index.php');
		}
	}
?>