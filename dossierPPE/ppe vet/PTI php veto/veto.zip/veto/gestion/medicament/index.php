﻿<?php
	
	require_once '../../utilities/secure.php';
	require_once '../../utilities/top.php';
	
	echo '<div id="content">';
	echo '<h1>Gestion des médicaments</h1>';
	echo '<div id="text">';
	$sql = mysql_query('SELECT numm, nomm, prixm FROM medicament');
	
	echo '<table id="liste"><tbody>';
	while($res = mysql_fetch_object($sql))
	{
		echo '<tr>';
		echo '<td id="libelle">'.$res->nomm.' (Prix : '.$res->prixm.')</a></td>';
		echo '<td id="modif"><a href="gestion_medicament.php?action=modif&id='.$res->numm.'">Modifier</a></td>';
		echo '<td id="supp"><a onclick="return(confirm(\' Etes-vous sûr de supprimer ce soin ?\'));" href="supp_medicament.php?id='.$res->numm.'">Supprimer</a></td>';
		echo '</tr>';
	}
	
	echo '</tbody></table>';
	
	echo '<p><a href="gestion_medicament.php?action=ajout">+ Ajouter un médicament</a></p>';
	echo '</div>'; // fermeture de la div text
	
	echo '</div>'; // fermeture de la div content
	
	require_once '../../utilities/footer.php';
?>