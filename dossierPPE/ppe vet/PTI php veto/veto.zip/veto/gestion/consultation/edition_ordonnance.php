﻿<?php
	
	require_once '../../utilities/secure.php';
	require_once '../../utilities/connect_db.php';
	
	if(!isset($_GET['id']))
	{
		header('Location: '.$_SERVER['HTTP_REFERER']);
	}
	else
	{
		$id = $_GET['id'];
		
		$sql = mysql_query('SELECT numc FROM consultation WHERE numc = '.$id);
		$nb = mysql_num_rows($sql);
		
		if($nb == 0)
		{
			header('Location: '.$_SERVER['HTTP_REFERER']);
		}
		else
		{
			$sql = mysql_query('SELECT * FROM prescrire WHERE numc = '.$id);
			$nb = mysql_num_rows($sql);
			if($nb == 0)
			{
				header('Location: '.$_SERVER['HTTP_REFERER']);
			}
		}
	}
	
	$fichier = '../../ordonnance/ordonnance_'.$id.'.txt';
	$handle = fopen($fichier,'w');
	
	$entete = "Docteur Durand Roger\r\n12 rue des Feuteries\r\n75016 Paris\r\nTéléphone : 01.47.96.15.32\r\nE-mail : roger.durand@gmail.com\r\n\r\n";
	fwrite($handle, $entete);
	
	$sql = mysql_query('SELECT date_format(datec, \'%d/%m/%Y\') AS datec FROM consultation WHERE numc = '.$id);
	$res = mysql_fetch_object($sql);
	
	$date = "\t\t\t\t\t\t\t\t\t\t\t\t\t\t".$res->datec."\r\n\r\n";
	fwrite($handle, $date);
	
	$sql = mysql_query('SELECT nomp, prenomp, adrp, codep, villep FROM proprietaire, animal, consultation WHERE numc = '.$id.' AND consultation.numa = animal.numa AND animal.nump = proprietaire.nump');
	$res = mysql_fetch_object($sql);
	
	$client = "\t\t\t\t\t\t\t\t\t\t\t\t\t\t".$res->nomp." ".$res->prenomp."\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t".$res->adrp."\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t".$res->codep." ".$res->villep."\r\n\r\n";
	fwrite($handle, $client);
	
	$sql = mysql_query('SELECT noma, tatouage, nomr FROM animal, race, consultation WHERE animal.numr = race.numr AND consultation.numa = animal.numa AND numc = '.$id);
	$res = mysql_fetch_object($sql);
	
	$animal = "\tNom de l'animal : ".$res->noma."\r\n\tTatouage : ".$res->tatouage."\r\n\tRace : ".$res->nomr."\r\n\r\n";
	fwrite($handle, $animal);
	
	$sep = "\t\t________________________________________________________________________________\r\n\r\n";
	fwrite($handle, $sep);
	
	$sql = mysql_query('SELECT nomm, prixm, quantite, posologie FROM medicament, prescrire WHERE prescrire.numm = medicament.numm AND prescrire.numc = '.$id);
	
	$general = 0;
	while($res = mysql_fetch_object($sql))
	{
		$total = $res->prixm * $res->quantite;
		$general = $general + $total;
		$medicament = "\t\t".$res->nomm."\r\n\t\tPosologie : ".$res->posologie."\r\n\t\tPrix : ".$res->prixm." Quantité : ".$res->quantite."\r\n\t\tTotal : ".$total."\r\n";
		
		fwrite($handle, $medicament);
		fwrite($handle, $sep);
	}
	
	fwrite($handle, "\r\n\r\n");
	
	$sql = mysql_query('SELECT prixc FROM consultation WHERE numc = '.$id);
	$res = mysql_fetch_object($sql);
	
	$prix = "\t\tPrix de la consultation : ".$res->prixc."\r\n\r\n";
	fwrite($handle, $prix);
	fwrite($handle, $sep);
	
	$global = $general + $res->prixc;
	
	$total = "\t\t\t\t\t\t\t\t\t\t\tTotal : ".$global."\r\n";
	fwrite($handle, $total);
	
	fclose($handle);
	
	header("Content-disposition: attachment; filename=ordonnance_".$id.".txt");
	header("Content-Type: application/force-download");
	header("Content-Transfer-Encoding: text/plain");
	header("Content-Length: ".filesize($fichier));
	header("Pragma: no-cache");
	header("Cache-Control: must-revalidate, post-check=0, pre-check=0, public");
	header("Expires: 0");
	readfile($fichier);	
?>