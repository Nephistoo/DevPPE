﻿<?php
	
	require_once '../../utilities/secure.php';
	require_once '../../utilities/top.php';
		
	echo '<div id="content">';
	echo '<h1>Gestion des consultations</h1>';
	echo '<div id="text">';
	
	$sql = mysql_query('SELECT consultation.numc, animal.numa, proprietaire.nump, date_format(datec,\'%d/%m/%Y\') AS datecons, date_format(heurec, \'%H:%i\') AS heurecons, noma, prixc, nomp, prenomp FROM proprietaire, consultation, animal WHERE proprietaire.nump = animal.nump AND consultation.numa = animal.numa ORDER BY datec DESC, heurec DESC');
	
	echo '<table id="liste"><tbody>';
	while($res = mysql_fetch_object($sql))
	{
		echo '<tr>';
		echo '<td><a href="../proprietaire/proprietaire.php?id='.$res->nump.'">'.$res->nomp.' '.$res->prenomp.'</a></td>';
		echo '<td><a href="../proprietaire/animal.php?id='.$res->numa.'">'.$res->noma.'</a></td>';			
		echo '<td><a href="consultation.php?id='.$res->numc.'">'.$res->datecons.' '.$res->heurecons.'</a></td>';			
		echo '<td>'.$res->prixc.'</td>';
		echo '<td><a onclick="return(confirm(\' Etes-vous sûr de supprimer cette consultation ?\'));" href="supp_consultation.php?id='.$res->numc.'">Supprimer</a></td>';
		echo '</tr>';
	}
	
	echo '</tbody></table>';
	
	echo '<p><a href="gestion_consultation.php?action=ajout">+ Ajouter une consultation</a></p>';
	echo '</div>'; // fermeture de la div text
	
	echo '</div>'; // fermeture de la div content
	
	require_once '../../utilities/footer.php';
?>