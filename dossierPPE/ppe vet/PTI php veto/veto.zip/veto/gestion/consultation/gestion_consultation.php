﻿<?php

	function date_valide($j, $m, $a)
	{
		if(!is_numeric($j) || !is_numeric($m) || !is_numeric($a) || $j < 1 || $j > 31 || $m < 1 || $m > 12 || $a > date('Y') || $a < 1970)
		{
			return 0;
		}
		else
		{
			switch($m)
			{
				case 1 : case 3 : case 5 : case 7 : case 8 : case 10 : case 12 :
					if($j >= 1 && $j <= 31) {return 1;}else{ return 0;} 
					break;
				case 4 : case 6 : case 9 : case 11 :
					if($j >= 1 && $j <= 30) {return 1;}else{return 0;}
					break;					
				case 2 :
					if( ($annee%4 == 0 && $annee%100 != 0) || $annee%400 == 0)
					{$fev = 29;}
					else
					{$fev = 28;}
					
					if($j >= 1 && $j <= $fev) {return 1;}else{return 0;}	
					break;
			}
		}	
	}
	
	function heure_valide($h, $m)
	{
		if(!is_numeric($h) || !is_numeric($m) || $h < 0 || $h > 23 || $m < 0 || $m > 59)
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
	
	require_once '../../utilities/secure.php';
	require_once '../../utilities/connect_db.php';
	
	if(isset($_POST['Valider']))
	{
		$jour = $_POST['jour'];
		$mois = $_POST['mois'];
		$annee = $_POST['annee'];
		$heure = $_POST['heure'];
		$minute = $_POST['minute'];
		$prix = $_POST['prix'];
		$animal = $_POST['animal'];
		
		if(!date_valide($jour,$mois, $annee) || !heure_valide($heure, $minute) || !is_numeric($prix))
		{
			echo '<script type="text/javascript" language="javascript">alert(\'Veuillez saisir correctement les différents champs !\');document.location.href = "'.$_SERVER['REQUEST_URI'].'" ;</script>';
		}
		else
		{
			$date = '"'.$annee.'-'.$mois.'-'.$jour.'"';
			$rdv = '"'.$heure.':'.$minute.':00"';
			
			$sql = mysql_query('SELECT numc FROM consultation WHERE datec = '.$date.' AND heurec = '.$rdv.'');
			$nb = mysql_num_rows($sql);
			
			if($nb == 0)
			{
				mysql_query('INSERT INTO consultation VALUES (NULL, '.$date.', '.$rdv.', '.$prix.', '.$animal.')') or die(mysql_error());
				$id = mysql_insert_id();
				echo '<script type="text/javascript" language="javascript">alert(\'Insertion réussie : veuillez maintenant compléter la consultation !\');document.location.href = "consultation.php?id='.$id.'" ;</script>';
			}
			else
			{
				echo '<script type="text/javascript" language="javascript">alert(\'Insertion impossible : une autre consultation a déjà eu lieu à la même heure !\');document.location.href = "'.$_SERVER['REQUEST_URI'].'";</script>';
			}
		}
	}
	else
	{
		require_once '../../utilities/top.php';			
		
		echo '<div id="content">';
		echo '<h1>Ajout d\'une consultation</h1>';
		
		echo '<div id="text">';
		
		echo '<form action="'.$_SERVER['REQUEST_URI'].'" method="POST">';
		echo '<table><tbody>';
		echo '<tr style="height: 40px">';
		echo '<td><label for="animal">Animal :</label></td>';
		echo '<td><select name="animal">';
		$sql = mysql_query('SELECT nomp, prenomp, animal.numa AS num, noma FROM animal, proprietaire WHERE animal.nump = proprietaire.nump');
		while($res = mysql_fetch_object($sql))
		{
			echo '<option value="'.$res->num.'">'.$res->nomp.' '.$res->prenomp.' - '.$res->noma.'</option>';
		}
		echo '</select></td>';
		echo '</tr>';
				
		echo '<tr style="height: 40px">';
		echo '<td>Date consultation :&nbsp;</td>';
		echo '<td>Jour : <input type="text" name="jour" value="" size="1" /> Mois : <input type="text" name="mois" value="" size="1"/> Année : <input type="text" name="annee" value="" size="1" /></td>';
		echo '</tr>';
		echo '<tr style="height: 40px">';
		echo '<td>Heure Consultation :&nbsp;</td>';
		echo '<td>Heure : <input type="text" name="heure" value="" size="1" /> Minute : <input type="text" name="minute" value="" size="1"/></td>';
		echo '</tr>';
		echo '<tr style="height: 40px">';
		echo '<td><label for="prix">Prix :&nbsp;</label></td>';
		echo '<td><input type="text" name="prix" value="" /></td>';
		echo '</tr>';
		echo '</tbody></table>';
		echo '<input type="submit" name="Valider" value="Valider"/>';
		echo '</form>';
				
		echo '</div>'; // fermeture de la div text
				
		echo '</div>'; // fermeture de la div content
		require_once '../../utilities/footer.php';
	}
?>