﻿<?php
	
	if($_POST['Valider'] != 'Valider')
	{
		header('Location: index.php');
	}
	else
	{
		$posologie = $_POST['posologie'];
		$quantite = $_POST['quantite'];
		
		if($posologie == '' ||(!is_numeric($quantite) && $quantite != ''))
		{
			echo '<script type="text/javascript" language="javascript">alert(\'Veuillez remplir correctement les différents champs !\');document.location.href = "'.$_SERVER['HTTP_REFERER'].'" ;</script>';
		}
		else
		{
			require_once '../../utilities/connect_db.php';
			$action = $_POST['action'];
			$medicament = $_POST['num'];
			$new_medicament = $_POST['medic'];
			$consultation = $_POST['id'];
			
			if($action == 'ajout')
			{
				$sql = mysql_query('SELECT * FROM prescrire WHERE numc = '.$consultation.' AND numm = '.$new_medicament);
				$nb = mysql_num_rows($sql);
				if($nb == 0)
				{
					if($quantite == '')
					{
						$requete = 'NULL';
					}
					else
					{
						$requete = $quantite;
					}
					if(mysql_query('INSERT INTO prescrire (numm, numc, posologie, quantite) VALUES ('.$new_medicament.', '.$consultation.', "'.$posologie.'", '.$requete.')'))
					{
						echo '<script type="text/javascript" language="javascript">alert(\'Insertion réussie\');document.location.href = "consultation.php?id='.$consultation.'" ;</script>';
					}
					else
					{
						echo '<script type="text/javascript" language="javascript">alert(\'L\'insertion a échouée. Veuillez contacter l\'administrateur du site !\');document.location.href = "'.$_SERVER['REQUEST_URI'].'" ;</script>';
					}
				}
				else
				{
					echo '<script type="text/javascript" language="javascript">alert(\' Une prescription de ce médicament a déjà été donnée pour cette consultation !\');document.location.href = "'.$_SERVER['REQUEST_URI'].'" ;</script>';
				}
			}
			
			if($action == 'modif')
			{
				$sql = mysql_query('SELECT * FROM prescrire WHERE posologie = '.$posologie.' AND quantite = '.$quantite.' AND numc = '.$consultation.' AND numm = '.$new_medicament);
				$nb = mysql_num_rows($sql);
				if($nb == 0)
				{
					if($quantite == '')
					{
						$requete = 'NULL';
					}
					else
					{
						$requete = $quantite;
					}
					
					if(mysql_query('UPDATE prescrire SET numm = '.$new_medicament.', posologie = "'.$posologie.'", quantite = '.$requete.' WHERE numc = '.$consultation.' AND numm = '.$medicament))
					{
						echo '<script type="text/javascript" language="javascript">alert(\'Modification réussie\');document.location.href = "consultation.php?id='.$consultation.'" ;</script>';
					}
					else
					{
						echo '<script type="text/javascript" language="javascript">alert(\'La modification a échouée. Veuillez contacter l\'administrateur du site !\');document.location.href = "'.$_SERVER['REQUEST_URI'].'" ;</script>';
					}
				}
				else
				{
					echo '<script type="text/javascript" language="javascript">alert(\' Une prescription de ce médicament a déjà été donnée pour cette consultation !\');document.location.href = "'.$_SERVER['REQUEST_URI'].'" ;</script>';
				}
			}
		}
	}
?>