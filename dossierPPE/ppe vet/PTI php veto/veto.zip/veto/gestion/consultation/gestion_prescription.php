﻿<?php

	require_once '../../utilities/secure.php';
	require_once '../../utilities/connect_db.php';
	
	if(!isset($_GET['action']))
	{
		header('Location: /veto/gestion/consultation/index.php');
	}
	else
	{
		$action = $_GET['action'];
		
		if($action == 'ajout' || isset($_GET['id']) || ($action == 'modif' && isset($_GET['num'])))
		{
			$id = $_GET['id'];
			
			$sql = mysql_query('SELECT numc FROM consultation WHERE numc = "'.$id.'"');
			$nb1 = mysql_num_rows($sql);
			
			if($action == 'modif')
			{
				$num = $_GET['num'];
				$sql = mysql_query('SELECT numm FROM prescrire WHERE numm= "'.$num.'" AND numc = "'.$id.'"');
				$nb2 = mysql_num_rows($sql);
			}
			else
			{
				$num = ''; 
				$nb2 = 1;
			}
			
			if($nb1 == 0 || $nb2 == 0) // on vérifie si l'id existe bien dans la table
			{
				header('Location: /veto/gestion/veterinaire/index.php');
			}
			else
			{
				require_once '../../utilities/top.php';			
			
				echo '<div id="content">';
			
				if($action == 'ajout') {$text = 'Ajout';}else{$text = 'Modification';}
			
				echo '<h1>'.$text.' d\'une prescription</h1>';
			
				echo '<div id="text">';
			
				if($action == 'modif') 
				{
					$sql = mysql_query('SELECT numm, posologie, quantite FROM prescrire WHERE numc = '.$id.' AND numm = '.$num);
					$res = mysql_fetch_object($sql);
					$num = $res->numm;
					$quantite = $res->quantite;
					$posologie = $res->posologie;
				}
				else
				{
					$num = '';
					$quantite = '';
					$posologie = '';
				}
			
				echo '<form action="action_prescription.php" method="POST">';
				echo '<input type="hidden" name="action" value="'.$action.'" />';
				echo '<input type="hidden" name="id" value="'.$id.'" />';
				echo '<input type="hidden" name="num" value="'.$num.'" />';
				echo '<table><tbody>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="medic">Médicament :</label></td>';
				echo '<td><select name="medic">';
				$sql_medoc = mysql_query('SELECT numm, nomm FROM medicament');
				while($res_medoc = mysql_fetch_object($sql_medoc))
				{
					if($num == $res_medoc->numm){$text = 'selected';}else{$text = '';}
					echo '<option '.$text.' value="'.$res_medoc->numm.'">'.$res_medoc->nomm.'</option>';
				}
				echo '</select></td>';
				echo '</tr>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="posologie">Posologie :&nbsp;</label></td>';
				echo '<td><input type="text" name="posologie" value="'.$posologie.'" /></td>';
				echo '</tr>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="quantite">Quantité :&nbsp;</label></td>';
				echo '<td><input type="text" name="quantite" value="'.$quantite.'" /></td>';
				echo '</tr>';				
				echo '</tbody></table>';
				echo '<input type="submit" name="Valider" value="Valider"/>';
				echo '</form>';
				
				echo '</div>'; // fermeture de la div text
				
				echo '</div>'; // fermeture de la div content
				require_once '../../utilities/footer.php';
			}
		}
		else
		{
				header('Location: /veto/gestion/veterinaire/index.php');
		}
	}
?>