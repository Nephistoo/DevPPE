<?php
	require_once '../../utilities/connect_db.php';

	if(!isset($_GET['id']))
	{
		header('Location: '.$_SERVER['HTTP_REFERER']);
	}
	else
	{
		$id = $_GET['id'];
		
		$sql = mysql_query('SELECT numc FROM consultation WHERE numc = "'.$id.'"');
		$nb = mysql_num_rows($sql);
		
		if($nb == 0)
		{
			header('Location: '.$_SERVER['HTTP_REFERER']);
		}
		else
		{
			$sql_delete = mysql_query('DELETE FROM consultation WHERE numc = '.$id);
			$sql_delete = mysql_query('DELETE FROM prescrire WHERE numc = '.$id);
			$sql_delete = mysql_query('DELETE FROM pratiquer WHERE numc = '.$id);
			header('Location: '.$_SERVER['HTTP_REFERER']);
		}
	}
?>