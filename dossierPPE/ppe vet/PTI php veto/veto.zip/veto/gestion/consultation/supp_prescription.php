<?php
	require_once '../../utilities/connect_db.php';

	if(!isset($_GET['id']) || !isset($_GET['num']))
	{
		header('Location: '.$_SERVER['HTTP_REFERER']);
	}
	else
	{
		$id = $_GET['id'];
		$num = $_GET['num'];
		
		$sql = mysql_query('SELECT numc FROM consultation WHERE numc = "'.$id.'"');
		$nb1 = mysql_num_rows($sql);
		
		$sql = mysql_query('SELECT numm FROM medicament WHERE numm = "'.$num.'"');
		$nb2 = mysql_num_rows($sql);
		
		if($nb1 == 0 || $nb2 == 0)
		{
			header('Location: '.$_SERVER['HTTP_REFERER']);
		}
		else
		{
			$sql_delete = mysql_query('DELETE FROM prescrire WHERE numc = '.$id.' AND numm = '.$num);
			header('Location: '.$_SERVER['HTTP_REFERER']);
		}
	}




?>