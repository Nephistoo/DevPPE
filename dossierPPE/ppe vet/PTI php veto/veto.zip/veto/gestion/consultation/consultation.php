﻿<?php
	
	require_once '../../utilities/secure.php';
	require_once '../../utilities/connect_db.php';
	
	if(!isset($_GET['id']))
	{
		header('Location /veto/gestion/consultation/index.php');
	}
	else
	{
		$id = $_GET['id'];
		
		$sql = mysql_query('SELECT numc FROM consultation WHERE numc = "'.$id.'"');
		$nb = mysql_num_rows($sql);
		
		if($nb == 0)
		{
			header('Location /veto/gestion/consultation/index.php');
		}
	}
	
	require_once '../../utilities/top.php';
	
	echo '<div id="content">';
	echo '<h1>Fiche consultation</h1>';
	echo '<div id="text">';
			
	$sql = mysql_query('SELECT animal.numa, proprietaire.nump, noma, nomr, nomp, prenomp, date_format(datec, \'%d/%m/%Y\') AS datec, date_format(heurec, \'%H:%i\') AS heurec, prixc
	FROM animal, race, proprietaire, consultation 
	WHERE animal.numa = consultation.numa 
	AND animal.numr = race.numr 
	AND animal.nump = proprietaire.nump 
	AND consultation.numc = '.$id);
	
	$res = mysql_fetch_object($sql);
	echo '<h2>Renseignements</h2>';
	echo '<p>';
	echo '<strong>Animal</strong> : <a href="../proprietaire/animal.php?id='.$res->numa.'">'.$res->noma.'</a> (<i>Race</i> : '.$res->nomr.')<br />';
	echo '<strong>Propriétaire</strong> : <a href="../proprietaire/proprietaire.php?id='.$res->nump.'">'.$res->nomp.' '.$res->prenomp.'</a><br />';
	echo '</p>';
	echo '<p>';
	echo '<strong>Consultation : </strong>'.$res->datec.' '.$res->heurec.'<br />';
	echo '<strong>Prix : </strong>'.$res->prixc;
	echo '</p>';
	
	$sql = mysql_query('SELECT medicament.numm, nomm, prixm, posologie, quantite FROM medicament, prescrire WHERE numc = '.$id.' AND medicament.numm = prescrire.numm');
	$nb = mysql_num_rows($sql);
	
	echo '<h2>Médicament(s) prescrit(s)</h2>';
	if($nb == 0)
	{
		echo '<p>Aucune prescription.</p>';
	}
	else
	{
		echo '<table id="liste"><tbody>';
		while($res = mysql_fetch_object($sql))
		{	
			echo '<tr>';
			echo '<td>'.$res->quantite.'</td>';
			echo '<td>'.$res->nomm.'</td>';
			echo '<td>'.$res->posologie.'</td>';
			echo '<td>'.$res->prixm.'</td>';
			echo '<td><a href="gestion_prescription.php?action=modif&id='.$id.'&num='.$res->numm.'">Modifier</a></td>';
			echo '<td><a onclick="return(confirm(\' Etes-vous sûr de supprimer cette prescription ?\'));" href="supp_prescription.php?id='.$id.'&num='.$res->numm.'">Supprimer</a></td>';
			echo '</tr>';
		}
		echo '</tbody></table>';
	}
	
	echo '<p><a href="gestion_prescription.php?action=ajout&id='.$id.'">+ Ajouter une prescription</a></p>';
	
	if($nb != 0)
	{
		echo '<p><a href="edition_ordonnance.php?id='.$id.'">Edition de l\'ordonnance</a></p>';
	}
	
	echo '</div>'; // fermeture de la div text
	
	echo '</div>'; // fermeture de la div content
			
	require_once '../../utilities/footer.php';
?>