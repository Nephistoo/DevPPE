<?php
	
	require_once '../utilities/top.php';
	require_once '../utilities/secure.php';
	
	echo '<p style="color:red;">Connexion ok</p>';
	
	require_once '../utilities/footer.php';
?>