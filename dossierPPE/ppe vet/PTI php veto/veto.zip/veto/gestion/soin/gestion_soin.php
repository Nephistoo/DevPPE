﻿<?php

	require_once '../../utilities/secure.php';
	require_once '../../utilities/connect_db.php';
	
	if(!isset($_GET['action']))
	{
		header('Location: /veto/gestion/soin/index.php');
	}
	else
	{
		$action = $_GET['action'];
		
		if($action == 'ajout' || ($action == 'modif' && isset($_GET['id'])))
		{				
			if($action == 'modif')
			{
				$id = $_GET['id'];
				$sql = mysql_query('SELECT nums FROM soin WHERE nums = "'.$id.'"');
				$nb = mysql_num_rows($sql);
			}
			else
			{
				$id = ''; 
				$nb = 1;
			}
			
			if($nb == 0) // on vérifie si l'id existe bien dans la table
			{
				header('Location: /veto/gestion/soin/index.php');
			}
			else
			{
				require_once '../../utilities/top.php';			
			
				echo '<div id="content">';
			
				if($action == 'ajout') {$text = 'Ajout';}else{$text = 'Modification';}
			
				echo '<h1>'.$text.' d\'un soin</h1>';
			
				echo '<div id="text">';
			
				if($action == 'modif') 
				{
					$sql = mysql_query('SELECT noms, durees, natures, tarifs FROM soin WHERE nums = '.$id);
					$res = mysql_fetch_object($sql);
					$nom = $res->noms;
					$duree = $res->durees;
					$nature = $res->natures;
					$tarif = $res->tarifs;
				}
				else
				{
					$nom = '';
					$duree = '';
					$nature = '';
					$tarif = '';
				}
			
				echo '<form action="action_soin.php" method="POST">';
				echo '<input type="hidden" name="action" value="'.$action.'" />';
				echo '<input type="hidden" name="id" value="'.$id.'" />';
				echo '<table><tbody>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="nom">Nom du soin :</label></td>';
				echo '<td><input type="text" name="nom" value="'.$nom.'"/></td>';
				echo '</tr>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="duree">Durée du soin :&nbsp;</label></td>';
				echo '<td><input type="text" name="duree" value="'.$duree.'" /></td>';
				echo '</tr>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="nature">Nature du soin :&nbsp;</label></td>';
				echo '<td>';
				echo '<select name="nature">';
				if($nature == 'externe') {$text1 = 'selected';}
				if($nature == 'chirurgie') {$text2 = 'selected';}
				if($nature == 'petite intervention') {$text3 = 'selected';}
				echo '<option '.$text1.'>externe</option>';
				echo '<option '.$text2.'>chirurgie</option>';
				echo '<option '.$text3.'>petite intervention</option>';
				echo '</select>';
				echo '</td>';
				echo '</tr>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="tarif">Tarif du soin :&nbsp;</label></td>';
				echo '<td><input type="text" name="tarif" value="'.$tarif.'" /></td>';
				echo '</tr>';
				
				echo '</tbody></table>';
				echo '<input type="submit" name="Valider" value="Valider"/>';
				echo '</form>';

				echo '</div>'; // fermeture de la div text

				echo '</div>'; // fermeture de la div content
				require_once '../../utilities/footer.php';
			}
		}
		else
		{
				header('Location: /veto/gestion/soin/index.php');
		}
	}
?>