﻿<?php
	
	if($_POST['Valider'] != 'Valider')
	{
		header('Location /veto/gestion/race/index.php');
	}
	else
	{
		$nom = $_POST['nom'];
		$duree = $_POST['duree'];
		$nature = $_POST['nature'];
		$tarif = $_POST['tarif'];
		
		if($nom == '' || $duree == '' || $nature == '' || $tarif == '' || !is_numeric($duree) || !is_numeric($tarif))
		{
			echo '<script type="text/javascript" language="javascript">alert(\'Veuillez remplir correctement les différents champs !\');document.location.href = "'.$_SERVER['HTTP_REFERER'].'" ;</script>';
		}
		else
		{
			require_once '../../utilities/connect_db.php';
			$action = $_POST['action'];
			$id = $_POST['id'];
			
			if($action == 'ajout')
			{
				$sql = mysql_query('SELECT nums FROM soin WHERE noms = "'.$nom.'"');
				$nb = mysql_num_rows($sql);
			
				if($nb != 0)
				{
					echo '<script type="text/javascript" language="javascript">alert(\'Ce soin existe déjà !\');document.location.href = "'.$_SERVER['HTTP_REFERER'].'" ;</script>';
				}
				else
				{
				
					if(mysql_query('INSERT INTO soin VALUES (NULL, "'.$nom.'", '.$duree.', "'.$nature.'", '.$tarif.')'))
					{
						echo '<script type="text/javascript" language="javascript">alert(\'Insertion réussie\');document.location.href = "index.php" ;</script>';
					}
					else
					{
						echo '<script type="text/javascript" language="javascript">alert(\'L\'insertion a échouée. Veuillez contacter l\'administrateur du site !\');document.location.href = "index.php" ;</script>';
					}
				}
			}
				
			if($action == 'modif')
			{
				if(mysql_query('UPDATE soin SET noms = "'.$nom.'", durees = '.$duree.', natures = "'.$nature.'", tarifs = '.$tarif.' WHERE nums = '.$id))
				{
					echo '<script type="text/javascript" language="javascript">alert(\'Modification réussie\');document.location.href = "index.php" ;</script>';
				}
				else
				{
					echo '<script type="text/javascript" language="javascript">alert(\'La modification a échouée. Veuillez contacter l\'administrateur du site !\');document.location.href = "index.php" ;</script>';
				}
			}
		}
	}
?>