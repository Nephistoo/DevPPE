﻿<?php
	
	require_once '../../utilities/secure.php';
	require_once '../../utilities/top.php';
	
	echo '<div id="content">';
	echo '<h1>Gestion des soins</h1>';
	echo '<div id="text">';
	$sql = mysql_query('SELECT nums, noms, durees, natures, tarifs FROM soin');
	
	echo '<table id="liste"><tbody>';
	while($res = mysql_fetch_object($sql))
	{
		echo '<tr>';
		echo '<td id="libelle">'.$res->noms.' (Nature : '.$res->natures.' - Durée : '.$res->durees.'min - Tarif : '.$res->tarifs.')</a></td>';
		echo '<td id="modif"><a href="gestion_soin.php?action=modif&id='.$res->nums.'">Modifier</a></td>';
		echo '<td id="supp"><a onclick="return(confirm(\' Etes-vous sûr de supprimer ce soin ?\'));" href="supp_soin.php?id='.$res->nums.'">Supprimer</a></td>';
		echo '</tr>';
	}
	
	echo '</tbody></table>';
	
	echo '<p><a href="gestion_soin.php?action=ajout">+ Ajouter</a></p>';
	echo '</div>'; // fermeture de la div text
	
	echo '</div>'; // fermeture de la div content
	
	require_once '../../utilities/footer.php';
?>