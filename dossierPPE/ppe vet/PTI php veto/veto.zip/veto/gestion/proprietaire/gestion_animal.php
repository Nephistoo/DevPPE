﻿<?php

	require_once '../../utilities/secure.php';
	require_once '../../utilities/connect_db.php';
	
	if(!isset($_GET['action']))
	{
		header('Location: /veto/gestion/proprietaire/index.php');
	}
	else
	{
		$action = $_GET['action'];
		
		if($action == 'ajout' || ($action == 'modif' && isset($_GET['id'])))
		{				
			if($action == 'modif')
			{
				$id = $_GET['id'];
				$sql = mysql_query('SELECT numa FROM animal WHERE numa = "'.$id.'"');
				$nb = mysql_num_rows($sql);
			}
			else
			{
				$id = ''; 
				$nb = 1;
			}
			
			if($nb == 0) // on vérifie si l'id existe bien dans la table
			{
				header('Location: /veto/gestion/proprietaire/index.php');
			}
			else
			{
				require_once '../../utilities/top.php';			
			
				echo '<div id="content">';
			
				if($action == 'ajout') {$text = 'Ajout';}else{$text = 'Modification';}
			
				echo '<h1>'.$text.' d\'un animal</h1>';
			
				echo '<div id="text">';
			
				if($action == 'modif') 
				{
					$sql = mysql_query('SELECT noma, year(datenaissa) AS annee, month(datenaissa) AS mois, day(datenaissa) AS jour, photo, tatouage, numr, nump FROM animal WHERE numa = '.$id);
					$res = mysql_fetch_object($sql);
					$nom = $res->noma;
					$annee = $res->annee;
					$mois = $res->mois;
					$jour = $res->jour;
					$tatouage = $res->tatouage;
					$fichier = $res->photo;
					$proprietaire = $res->nump;
					$race = $res->numr;
				}
				else
				{
					$nom = '';
					$annee = '';
					$mois = '';
					$jour = '';
					$tatouage = '';
					$fichier = '';
					$proprietaire = '';
					$race = '';
				}
				
				if($fichier != '') 
				{
					echo '<img id="photo" src="'.$fichier.'" />';
				}
				else
				{
					echo '<p>Pas d\'image</p>';
				}
				
				echo '<form enctype="multipart/form-data" action="action_animal.php" method="POST">';
				echo '<input type="hidden" name="action" value="'.$action.'" />';
				echo '<input type="hidden" name="id" value="'.$id.'" />';
				echo '<table><tbody>';
				
				echo '<tr style="height: 40px">';
				echo '<td><label for="race">Race :</label></td>';
				echo '<td><select name="race">';
				$sql_race = mysql_query('SELECT numr, nomr FROM race');
				while($res_race = mysql_fetch_object($sql_race))
				{
					if($race == $res_race->numr){$text = 'selected';}else{$text = '';}
					echo '<option '.$text.' value="'.$res_race->numr.'">'.$res_race->nomr.'</option>';
				}
				echo '</select></td>';
				echo '</tr>';
				echo '<td><label for="proprietaire">Propriétaire :</label></td>';
				echo '<td><select name="proprietaire">';
				$sql_prop = mysql_query('SELECT nump, nomp, prenomp FROM proprietaire');
				while($res_prop = mysql_fetch_object($sql_prop))
				{
					if($proprietaire == $res_prop->nump){$text = 'selected';}else{$text = '';}
					echo '<option '.$text.' value="'.$res_prop->nump.'">'.$res_prop->nump.' - '.$res_prop->nomp.' '.$res_prop->prenomp.'</option>';
				}
				echo '</select></td>';
				echo '</tr>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="nom">Nom :</label></td>';
				echo '<td><input type="text" name="nom" value="'.$nom.'"/></td>';
				echo '</tr>';
				echo '<tr style="height: 40px">';
				echo '<td>Date naissance :&nbsp;</td>';
				echo '<td>Jour : <input type="text" name="jour" value="'.$jour.'" size="1" /> Mois : <input type="text" name="mois" value="'.$mois.'" size="1"/> Année : <input type="text" name="annee" value="'.$annee.'" size="1" /></td>';
				echo '</tr>';
				
				echo '<tr style="height: 40px">';
				echo '<td><label for="tatouage">Tatouage :</label></td>';
				echo '<td><input type="text" name="tatouage" value="'.$tatouage.'"/></td>';
				echo '</tr>';
				
				echo '<tr style="height: 40px">';
				echo '<td><label for="fichier">Photo :</label></td>';
				echo '<td><input name="fichier" id="fichier" type="file" /></td></tr>';	
				
				echo '</tbody></table>';
				echo '<input type="submit" name="Valider" value="Valider"/>';
				echo '</form>';

				echo '</div>'; // fermeture de la div text

				echo '</div>'; // fermeture de la div content
				require_once '../../utilities/footer.php';
			}
		}
		else
		{
			header('Location: /veto/gestion/proprietaire/index.php');
		}
	}
?>