﻿<?php
	
	require_once '../../utilities/secure.php';
	require_once '../../utilities/top.php';
		
	echo '<div id="content">';
	echo '<h1>Gestion des propriétaires</h1>';
	echo '<div id="text">';
	echo '<p><a href="gestion_proprietaire.php?action=ajout">+ Ajouter un propriétaire</a></p>';
	
	$sql = mysql_query('SELECT nump, nomp, prenomp, adrp, codep, villep, telp FROM proprietaire');
	
	while($res = mysql_fetch_object($sql))
	{	
		$num = $res->nump;
		echo '<p>';
		echo '<strong>Nom Prénom</strong> : <a href="proprietaire.php?id='.$num.'">'.$res->nomp.' '.$res->prenomp.'</a>';
		echo '<br />';
		echo '<strong>Adresse : </strong>'.$res->adrp.', '.$res->codep.', '.$res->villep;
		echo '<br />';
		echo '<strong>Téléphone : </strong>'.$res->telp;
		
		echo '<br /><a href="gestion_proprietaire.php?action=modif&id='.$num.'">* Modifier ce propriétaire</a>';
		echo '<br /><a onclick="return(confirm(\' Etes-vous sûr de supprimer ce propriétaire ?\'));" href="supp_proprietaire.php?id='.$num.'">- Supprimer ce propriétaire</a>';
		
		/*$sql_a = mysql_query('SELECT numa, noma, date_format(datenaissa, \'%d/%m/%Y\') AS datenaissa, tatouage, nomr FROM animal, race WHERE animal.numr = race.numr AND nump = '.$num);
		$nb = mysql_num_rows($sql);
		
		if($nb == 0)
		{
			echo '<br />Aucun animal n\'a été enregistré pour ce propriétaire !';
		}
		else
		{
			echo '<table id="liste"><tbody>';
			while($res_a = mysql_fetch_object($sql_a))
			{
				echo '<tr>';
				echo '<td>'.$res_a->noma.'</td>';
				echo '<td>'.$res_a->nomr.'</td>';
				echo '<td>'.$res_a->datenaissa.'</td>';
				echo '<td>'.$res_a->tatouage.'</td>';
				echo '<td><a href="gestion_animal.php?action=modif&id='.$res_a->numa.'">Modifier</a></td>';
				echo '<td><a onclick="return(confirm(\' Etes-vous sûr de supprimer cet animal ?\'));" href="supp_animal.php?id='.$res_a->numa.'">Supprimer</a></td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
		echo '<a href="gestion_animal.php?action=ajout">+ Ajouter un animal</a>';
		
		echo '</p>';
		*/
		echo '<hr />';
	}
	
	echo '<p><a href="gestion_proprietaire.php?action=ajout">+ Ajouter un propriétaire</a></p>';
	echo '</div>'; // fermeture de la div text
	
	echo '</div>'; // fermeture de la div content
	
	require_once '../../utilities/footer.php';
?>