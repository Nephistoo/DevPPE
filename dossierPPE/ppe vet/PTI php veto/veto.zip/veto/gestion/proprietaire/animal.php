﻿<?php
	
	require_once '../../utilities/secure.php';
	
	if(!isset($_GET['id']))
	{
		header('Location: index.php');
	}
	else
	{
		require_once '../../utilities/connect_db.php';
		
		$id = $_GET['id'];		
		$sql = mysql_query('SELECT * FROM animal WHERE numa = '.$id);
		$nb = mysql_num_rows($sql);
		
		if($nb == 0) 
		{
			header('Location : index.php');
		}
	}	
	
	require_once '../../utilities/top.php';
	
	$sql = mysql_query('SELECT numa, noma, date_format(datenaissa,\'%d/%m/%Y\') As date, photo, tatouage, nomr, nomp, prenomp FROM animal, race, proprietaire WHERE animal.numr = race.numr AND proprietaire.nump = animal.nump AND numa = '.$id);
	$res = mysql_fetch_object($sql);
	
	echo '<div id="content">';
	echo '<h1>Fiche animal : '.$res->noma.'</h1>';
	echo '<div id="text">';
	echo '<img id="photo" src="../../images/'.$res->photo.'" />';
	echo '<p>';
	echo '<strong>Date Naissance</strong> : '.$res->date;
	echo '<br />';
	echo '<strong>Tatouage</strong> : '.$res->tatouage;
	echo '<br />';
	echo '<strong>Race </strong> : '.$res->nomr;
	echo '<br />';
	echo '<strong>Propriétaire </strong> : '.$res->nomp.' '.$res->prenomp;
	echo '<br />';
	echo '</p>';
	
	$sql = mysql_query('SELECT numc, date_format(datec, \'%d/%m/%Y\') AS datec, date_format(heurec, \'%H:%i\') AS heurec, prixc FROM consultation WHERE numa = '.$id);
	$nb = mysql_num_rows($sql);
	
	if($nb == 0)
	{
		echo '<br />Aucune consultation n\'a été enregistrée pour cet animal !';
	}
	else
	{
		echo '<table id="liste"><tbody>';
		while($res = mysql_fetch_object($sql))
		{
			echo '<tr>';
			echo '<td><a href="../consultation/consultation.php?id='.$res->numc.'">'.$res->datec.' '.$res->heurec.'</a></td>';
			echo '<td>'.$res->prixc.'</td>';
			echo '<td><a href="../consultation/gestion_consultation.php?action=modif&id='.$res->numc.'">Modifier</a></td>';
			echo '<td><a onclick="return(confirm(\' Etes-vous sûr de supprimer cette consultation ?\'));" href="../consultation/supp_consultation.php?id='.$res->numc.'">Supprimer</a></td>';
			echo '</tr>';
		}
		echo '</tbody></table>';
	}
	
	echo '</div>'; // fermeture de la div text
	
	echo '</div>'; // fermeture de la div content
	
	require_once '../../utilities/footer.php';
?>