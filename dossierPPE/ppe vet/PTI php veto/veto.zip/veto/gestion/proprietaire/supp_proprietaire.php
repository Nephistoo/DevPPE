﻿<?php
	require_once '../../utilities/connect_db.php';

	if(!isset($_GET['id']))
	{
		header('Location: /veto/gestion/proprietaire/index.php');
	}
	else
	{
		$id = $_GET['id'];
		
		$sql = mysql_query('SELECT nump FROM proprietaire WHERE nump = "'.$id.'"');
		$nb = mysql_num_rows($sql);
		
		if($nb == 0)
		{
			header('Location: /veto/gestion/proprietaire/index.php');
		}
		else
		{
			$sql = mysql_query('SELECT numa FROM animal WHERE nump = '.$id);
			$nb = mysql_num_rows($sql);
			
			if($nb == 0)
			{	
				$sql_delete = mysql_query('DELETE FROM proprietaire WHERE nump = "'.$id.'"');
				header('Location: /veto/gestion/proprietaire/index.php');
			}
			else
			{
				echo '<script type="text/javascript" language="javascript">alert(\'Suppression impossible : il existe des animaux associés à ce propriétaire !\');document.location.href = "/veto/gestion/proprietaire/index.php" ;</script>';
			}
		}
	}
?>