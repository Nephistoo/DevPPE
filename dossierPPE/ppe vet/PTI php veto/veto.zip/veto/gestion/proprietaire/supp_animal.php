﻿<?php
	require_once '../../utilities/connect_db.php';

	if(!isset($_GET['id']))
	{
		header('Location: '.$_SERVER['HTTP_REFERER']);
	}
	else
	{
		$id = $_GET['id'];
		
		$sql = mysql_query('SELECT numa FROM animal WHERE numa = "'.$id.'"');
		$nb = mysql_num_rows($sql);
		
		if($nb == 0)
		{
			header('Location: '.$_SERVER['HTTP_REFERER']);
		}
		else
		{
			$sql = mysql_query('SELECT photo FROM animal WHERE numa = "'.$id.'"');
			$res = mysql_fetch_object($sql);
			$img = $res->photo;
			if($img != ""){unlink('../../images/'.$img);}
			
			
			$sql_delete = mysql_query('DELETE FROM animal WHERE numa = "'.$id.'"');
			header('Location: '.$_SERVER['HTTP_REFERER']);
		}
	}




?>