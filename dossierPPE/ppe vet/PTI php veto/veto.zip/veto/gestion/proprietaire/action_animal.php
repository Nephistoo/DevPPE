﻿<?php

	function date_valide($j, $m, $a)
	{
		if(!is_numeric($j) || !is_numeric($m) || !is_numeric($a) || $j < 1 || $j > 31 || $m < 1 || $m > 12 || $a > date('Y') || $a < 1970)
		{
			return 0;
		}
		else
		{
			switch($m)
			{
				case 1 : case 3 : case 5 : case 7 : case 8 : case 10 : case 12 :
					if($j >= 1 && $j <= 31) {return 1;}else{ return 0;} 
					break;
				case 4 : case 6 : case 9 : case 11 :
					if($j >= 1 && $j <= 30) {return 1;}else{return 0;}
					break;					
				case 2 :
					if( ($annee%4 == 0 && $annee%100 != 0) || $annee%400 == 0)
					{$fev = 29;}
					else
					{$fev = 28;}
					
					if($j >= 1 && $j <= $fev) {return 1;}else{return 0;}	
					break;
			}
		}	
	}	
	
	function redim_img($file_name)
	{
		$default_image = '../../images/chat.gif';
		
		$max_larg = 200;
		$max_haut = 200;
		
		$size = getimagesize($file_name);
		$default_size = getimagesize($default_image);
		
		$larg = $size[0];
		$haut = $size[1];
		if($larg == "")
		{
			$larg = $default_size[0];
			$haut = $default_size[1];
		}
		$ext  = image_type_to_mime_type($size[2]);
		
		$new_larg = 0;
		$new_haut = 0;
		
		if(($larg >= $haut) && ($larg > $max_larg))
		{
			$new_larg = $max_larg;
			$new_haut = $haut * ($max_larg / $larg);
			
		}
		else if(($haut >= $larg) && ($haut > $max_haut))
		{		
			$new_haut = $max_haut;
			$new_larg = $larg * ($max_haut / $haut);
		}
		else
		{
			$new_haut = $haut;
			$new_larg = $larg;
		}
		
		$new_haut = round($new_haut);
		$new_larg = round($new_larg);
		
		$rendu = imagecreatetruecolor($new_larg, $new_haut);
		$rendu_defaut = imagecreatetruecolor($new_larg, $new_haut);
		
		switch($ext)
		{
			case 'image/jpeg': 	
				$source = @imagecreatefromjpeg($file_name);
				if(!$source) 
				{
					//echo 'Erreur de chargement de '.$file_name.': ce n\'est pas un fichier .jpg valide. La miniature par d&eacute;faut a &eacute;t&eacute; cr&eacute;&eacute;e.';
					$defaut = @imagecreatefromgif($default_image);
					imagecopyresampled($rendu_defaut, $defaut, 0, 0, 0, 0, $default_size[0], $default_size[1], $default_size[0], $default_size[1]);
					imagejpeg($rendu_defaut,$file_name);
					
					return false;
				}
				imagecopyresampled($rendu, $source, 0, 0, 0, 0, $new_larg, $new_haut, $larg, $haut);
				return imagejpeg($rendu,$file_name);
				break;
				
			case 'image/gif':
				$source = @imagecreatefromgif($file_name);
				if(!$source) 
				{
					//echo 'Erreur de chargement de '.$file_name.': ce n\'est pas un fichier .gif valide. La miniature par d&eacute;faut a &eacute;t&eacute; cr&eacute;&eacute;e.';
					$defaut = @imagecreatefromgif($default_image);
					imagecopyresampled($rendu_defaut, $defaut, 0, 0, 0, 0, $default_size[0], $default_size[1], $default_size[0], $default_size[1]);
					imagejpeg($rendu_defaut,$file_name);
					
					return false;
				}					
   				imagecopyresampled($rendu, $source, 0, 0, 0, 0, $new_larg, $new_haut, $larg, $haut);
   				return imagejpeg($rendu,$file_name);   				
				break;
				
			case 'image/png':	$source = @imagecreatefrompng($file_name);
				if(!$source) 
				{
					//echo 'Erreur de chargement de '.$file_name.': ce n\'est pas un fichier .png valide. La miniature par d&eacute;faut a &eacute;t&eacute; cr&eacute;&eacute;e.';
					$defaut = @imagecreatefromgif($default_image);
					imagecopyresized($rendu_defaut, $defaut, 0, 0, 0, 0, $default_size[0], $default_size[1], $default_size[0], $default_size[1]);
					imagejpeg($rendu_defaut,$file_name);					
					return false;							
				}						
   				imagecopyresampled($rendu, $source, 0, 0, 0, 0, $new_larg, $new_haut, $larg, $haut);
   				return imagejpeg($rendu,$file_name);
				break;
			default:
				$defaut = @imagecreatefromgif($default_image);
				imagecopyresampled($rendu_defaut, $defaut, 0, 0, 0, 0, $default_size[0], $default_size[1], $default_size[0], $default_size[1]);
				return imagejpeg($rendu_defaut,$file_name);
				break;
		}
	}
	
	if($_POST['Valider'] != 'Valider')
	{
		header('Location /veto/gestion/race/index.php');
	}
	else
	{
		//print_r($_POST);
		$nom = $_POST['nom'];
		$annee = $_POST['annee'];
		$mois = $_POST['mois'];
		$jour = $_POST['jour'];
		$tatouage = $_POST['tatouage'];
		$proprietaire = $_POST['proprietaire'];
		$race = $_POST['race'];
		
		$target = "../../images/"; // Repertoire cible
		$extension = 'jpg'; // Extension du fichier
		$max_size = 1000000; // Taille max en octets du fichier
		$new_larg = 20; // Largeur max de l'image en pixels
		$new_haut = 20; // Hauteur max de l'image en pixels
		
		//  Definition des variable liees au fichier
		$nom_file = $_FILES['fichier']['name'];
		$taille = $_FILES['fichier']['size'];
		$tmp = $_FILES['fichier']['tmp_name'];		
		
		if($nom == '' || (!date_valide($jour, $mois, $annee) && $jour != '' && $mois != '' && $annee != ''))
		{
			echo '<script type="text/javascript" language="javascript">alert(\'Veuillez remplir correctement les différents champs !\');document.location.href = "'.$_SERVER['HTTP_REFERER'].'" ;</script>';
		}
		else
		{
			require_once '../../utilities/connect_db.php';
			$action = $_POST['action'];
			$id = $_POST['id'];
			
			if($action == 'ajout')
			{
				$sql = mysql_query('SELECT numa FROM animal WHERE noma = "'.$nom.'" AND tatouage = "'.$tatouage.'"');
				$nb = mysql_num_rows($sql);
				if($nb != 0)
				{
					echo '<script type="text/javascript" language="javascript">alert(\'Cet animal existe déjà !\');document.location.href = "'.$_SERVER['HTTP_REFERER'].'" ;</script>';
				}
				else
				{
					if($jour == '')
					{
						$requete = 'NULL';
					}
					else
					{
						$requete = '"'.$annee.'-'.$mois.'-'.$jour.'"';
					}
						
					if($tatouage == '')
					{
						$requete2 = 'NULL';
					}
					else
					{
						$requete2 = '"'.$tatouage.'"';
					}
					
					if($nom_file == "")
					{
						$requete3 = 'NULL';
					}
					else					
					{
						$sql = mysql_query('SELECT AUTO_INCREMENT as last_id FROM INFORMATION_SCHEMA.TABLES WHERE table_name = "animal"');
						$res = mysql_fetch_object($sql);
						$id = $res->last_id + 1;
						
						$new_name = $id.'_photo.jpg';
						
						if(move_uploaded_file($tmp,$target.$new_name))
						{	
							redim_img($target.$new_name);
							$requete3 = '"'.$new_name.'"';							
						}
						else
						{
							echo '<script type="text/javascript" language="javascript">alert(\'L\'upload de la photo a échoué. Veuillez contacter l\'administrateur du site !\');document.location.href = "index.php" ;</script>';
						}
					}
					
					if(mysql_query('INSERT INTO animal (noma, datenaissa, tatouage, photo, numr, nump) VALUES ("'.$nom.'", '.$requete.', '.$requete2.', '.$requete3.', '.$race.', '.$proprietaire.' )'))
					{
						echo '<script type="text/javascript" language="javascript">alert(\'Insertion réussie\');document.location.href = "proprietaire.php?id='.$proprietaire.'" ;</script>';
					}
					else
					{
						echo '<script type="text/javascript" language="javascript">alert(\'L\'insertion a échouée. Veuillez contacter l\'administrateur du site !\');document.location.href = "index.php" ;</script>';
					}
				}
			}
				
			if($action == 'modif')
			{
				if($jour == '')
				{
					$requete = '';
				}
				else
				{
					$requete = ', datenaissa = "'.$annee.'-'.$mois.'-'.$jour.'"';
				}
					
				if($tatouage == '')
				{
					$requete2 = '';
				}
				else
				{
					$requete2 = ', tatouage = "'.$tatouage.'"';
				}				
				
				if($nom_file == "")
				{
					$requete3 = '';
				}
				else
				{
					$new_name = $id.'_photo.jpg';
					
					$sql = mysql_query('SELECT photo FROM animal WHERE numa = "'.$id.'"');
					$res = mysql_fetch_object($sql);
					$img = $res->photo;
					if($img != ""){unlink('../../images/'.$img);}
					
					$new_name = $id.'_photo.jpg';
					
					if(move_uploaded_file($tmp,$target.$new_name))
					{	
						redim_img($target.$new_name);
						$requete3 = ', photo = "'.$new_name.'"';
					}
					else
					{
						echo '<script type="text/javascript" language="javascript">alert(\'L\'upload de la photo a échoué. Veuillez contacter l\'administrateur du site !\');document.location.href = "index.php" ;</script>';
					}
				}
				
				if(mysql_query('UPDATE animal SET noma = "'.$nom.'" '.$requete.' '.$requete2.' '.$requete3.', numr = '.$race .', nump = '.$proprietaire.' WHERE numa = '.$id))
				{
					echo '<script type="text/javascript" language="javascript">alert(\'Modification réussie\');document.location.href = "proprietaire.php?id='.$proprietaire.'" ;</script>';
				}
				else
				{
					echo '<script type="text/javascript" language="javascript">alert(\'La modification a échouée. Veuillez contacter l\'administrateur du site !\');document.location.href = "index.php" ;</script>';
				}
			}
		}
	}
?>