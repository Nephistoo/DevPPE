﻿<?php

	require_once '../../utilities/secure.php';
	require_once '../../utilities/connect_db.php';
	
	if(!isset($_GET['action']))
	{
		header('Location: /veto/gestion/proprietaire/index.php');
	}
	else
	{
		$action = $_GET['action'];
		
		if($action == 'ajout' || ($action == 'modif' && isset($_GET['id'])))
		{				
			if($action == 'modif')
			{
				$id = $_GET['id'];
				$sql = mysql_query('SELECT nump FROM proprietaire WHERE nump = "'.$id.'"');
				$nb = mysql_num_rows($sql);
			}
			else
			{
				$id = ''; 
				$nb = 1;
			}
			
			if($nb == 0) // on vérifie si l'id existe bien dans la table
			{
				header('Location: /veto/gestion/proprietaire/index.php');
			}
			else
			{
				require_once '../../utilities/top.php';			
			
				echo '<div id="content">';
			
				if($action == 'ajout') {$text = 'Ajout';}else{$text = 'Modification';}
			
				echo '<h1>'.$text.' d\'une race</h1>';
			
				echo '<div id="text">';
			
				if($action == 'modif') 
				{
					$sql = mysql_query('SELECT nomp, prenomp, adrp, codep, villep, telp FROM proprietaire WHERE nump = '.$id);
					$res = mysql_fetch_object($sql);
					$nom = $res->nomp;
					$prenom = $res->prenomp;
					$adresse = $res->adrp;
					$code = $res->codep;
					$ville = $res->villep;
					$tel = $res->telp;
				}
				else
				{
					$nom = '';
					$prenom = '';
					$adresse = '';
					$code = '';
					$ville = '';
					$tel = '';
				}
			
				echo '<form action="action_proprietaire.php" method="POST">';
				echo '<input type="hidden" name="action" value="'.$action.'" />';
				echo '<input type="hidden" name="id" value="'.$id.'" />';
				echo '<table><tbody>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="nom">Nom :</label></td>';
				echo '<td><input type="text" name="nom" value="'.$nom.'"/></td>';
				echo '</tr>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="prenom">Prénom :</label></td>';
				echo '<td><input type="text" name="prenom" value="'.$prenom.'"/></td>';
				echo '</tr>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="adresse">Adresse :</label></td>';
				echo '<td><input type="text" name="adresse" value="'.$adresse.'"/></td>';
				echo '</tr>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="code">Code postal :</label></td>';
				echo '<td><input type="text" name="code" value="'.$code.'"/></td>';
				echo '</tr>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="ville">Ville :</label></td>';
				echo '<td><input type="text" name="ville" value="'.$ville.'"/></td>';
				echo '</tr>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="tel">Téléphone :</label></td>';
				echo '<td><input type="text" name="tel" value="'.$tel.'" /></td>';
				echo '</tr>';
				
				echo '</tbody></table>';
				echo '<input type="submit" name="Valider" value="Valider"/>';
				echo '</form>';

				echo '</div>'; // fermeture de la div text

				echo '</div>'; // fermeture de la div content
				require_once '../../utilities/footer.php';
			}
		}
		else
		{
				header('Location: /veto/gestion/proprietaire/index.php');
		}
	}
?>