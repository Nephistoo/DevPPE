﻿<?php
	
	require_once '../../utilities/secure.php';
	
	if(!isset($_GET['id']))
	{
		header('Location: index.php');
	}
	else
	{
		require_once '../../utilities/connect_db.php';
		
		$id = $_GET['id'];		
		$sql = mysql_query('SELECT * FROM proprietaire WHERE nump = '.$id);
		$nb = mysql_num_rows($sql);
		
		if($nb == 0) 
		{
			header('Location : index.php');
		}
	}	
	
	require_once '../../utilities/top.php';
	
	$sql = mysql_query('SELECT nump, nomp, prenomp, adrp, codep, villep, telp FROM proprietaire WHERE nump = '.$id);
	$res = mysql_fetch_object($sql);
	
	echo '<div id="content">';
	echo '<h1>Fiche propriétaire : '.$res->nomp.' '.$res->prenomp.'</h1>';
	echo '<div id="text">';
	
	echo '<p>';
	echo '<strong>Adresse</strong> : '.$res->adrp.', '.$res->codep.', '.$res->villep;
	echo '<br />';
	echo '<strong>Téléphone</strong> : '.$res->telp;
	echo '</p>';
	
	$sql = mysql_query('SELECT numa, noma, date_format(datenaissa, \'%d/%m/%Y\') AS datenaissa, tatouage, nomr FROM animal, race WHERE animal.numr = race.numr AND nump = '.$id);
	$nb = mysql_num_rows($sql);
	
	if($nb == 0)
	{
		echo '<br />Aucun animal n\'a été enregistré pour ce propriétaire !<br/>';
	}
	else
	{
		echo '<table id="liste"><tbody>';
		while($res = mysql_fetch_object($sql))
		{
			echo '<tr>';
			echo '<td><a href="animal.php?id='.$res->numa.'">'.$res->noma.'</a></td>';
			echo '<td>'.$res->nomr.'</td>';
			echo '<td>'.$res->datenaissa.'</td>';
			echo '<td>'.$res->tatouage.'</td>';
			echo '<td><a href="gestion_animal.php?action=modif&id='.$res->numa.'">Modifier</a></td>';
			echo '<td><a onclick="return(confirm(\' Etes-vous sûr de supprimer cet animal ?\'));" href="supp_animal.php?id='.$res->numa.'">Supprimer</a></td>';
			echo '</tr>';
		}
		echo '</tbody></table>';
	}
	echo '<a href="gestion_animal.php?action=ajout">+ Ajouter un animal</a>';
	
	echo '</div>'; // fermeture de la div text
	
	echo '</div>'; // fermeture de la div content
	
	require_once '../../utilities/footer.php';
?>