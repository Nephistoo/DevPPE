﻿<?php
	
	if($_POST['Valider'] != 'Valider')
	{
		header('Location /veto/gestion/proprietaire/index.php');
	}
	else
	{
		$nom = $_POST['nom'];
		$prenom = $_POST['prenom'];
		$adresse = $_POST['adresse'];
		$code = $_POST['code'];
		$ville = $_POST['ville'];
		$tel = $_POST['tel'];
		
		if($nom == '' || $prenom == '' || $adresse == '' || $code == '' || $ville == '' || $tel == '' || !is_numeric($code) || !is_numeric($tel))
		{
			echo '<script type="text/javascript" language="javascript">alert(\'Veuillez remplir correctement les différents champs !\');document.location.href = "'.$_SERVER['HTTP_REFERER'].'" ;</script>';
		}
		else
		{
			require_once '../../utilities/connect_db.php';
			$action = $_POST['action'];
			$id = $_POST['id'];
			if($action == 'ajout')
			{
				$sql = mysql_query('SELECT nump FROM proprietaire WHERE nomp = "'.$nom.'" AND prenomp = "'.$prenom.'" AND telp = '.$tel);
				$nb = mysql_num_rows($sql);
				if($nb != 0)
				{
					echo '<script type="text/javascript" language="javascript">alert(\'Ce propriétaire existe déjà !\');document.location.href = "'.$_SERVER['HTTP_REFERER'].'" ;</script>';
				}
				else
				{
					if(mysql_query('INSERT INTO proprietaire VALUES (NULL, "'.$nom.'", "'.$prenom.'", "'.$adresse.'", '.$code.', "'.$ville.'", '.$tel.')'))
					{
						echo '<script type="text/javascript" language="javascript">alert(\'Insertion réussie\');document.location.href = "index.php" ;</script>';
					}
					else
					{
						echo '<script type="text/javascript" language="javascript">alert(\'L\'insertion a échouée. Veuillez contacter l\'administrateur du site !\');document.location.href = "index.php" ;</script>';
					}
				}
			}
				
			if($action == 'modif')
			{	
				if(mysql_query('UPDATE proprietaire SET nomp = "'.$nom.'", prenomp = "'.$prenom.'", adrp = "'.$adresse.'", codep = '.$code.', villep = "'.$ville.'", telp = '.$tel.' WHERE nump = '.$id))
				{
					echo '<script type="text/javascript" language="javascript">alert(\'Modification réussie\');document.location.href = "index.php" ;</script>';
				}
				else
				{
					echo '<script type="text/javascript" language="javascript">alert(\'La modification a échouée. Veuillez contacter l\'administrateur du site !\');document.location.href = "index.php" ;</script>';
				}
			}
		}
	}
?>