<?php
	require_once '../../utilities/connect_db.php';

	if(!isset($_GET['id']))
	{
		header('Location: /veto/gestion/veterinaire/index.php');
	}
	else
	{
		$id = $_GET['id'];
		
		$sql = mysql_query('SELECT numv FROM veterinaire WHERE numv = "'.$id.'"');
		$nb = mysql_num_rows($sql);
		
		if($nb == 0)
		{
			header('Location: /veto/gestion/veterinaire/index.php');
		}
		else
		{
			$sql_delete = mysql_query('DELETE FROM veterinaire WHERE numv = "'.$id.'"');
			header('Location: /veto/gestion/veterinaire/index.php');
		}
	}




?>