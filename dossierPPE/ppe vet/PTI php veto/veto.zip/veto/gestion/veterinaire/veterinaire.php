﻿<?php
	
	require_once '../../utilities/secure.php';
	require_once '../../utilities/connect_db.php';
	
	if(!isset($_GET['id']))
	{
		header('Location /veto/gestion/veterinaire/index.php');
	}
	else
	{
		$id = $_GET['id'];
		
		$sql = mysql_query('SELECT numv FROM veterinaire WHERE numv = "'.$id.'"');
		$nb = mysql_num_rows($sql);
		
		if($nb == 0)
		{
			header('Location /veto/gestion/veterinaire/index.php');
		}
		else
		{
			require_once '../../utilities/top.php';
			
			echo '<div id="content">';
			
			$sql = mysql_query('SELECT nomv, prenomv FROM veterinaire WHERE numv = '.$id);
			$res = mysql_fetch_object($sql);
			echo '<h1>Fiche vétérinaire : '.$res->nomv.' '.$res->prenomv.'</h1>';
			echo '<div id="text">';
			
			$sql = mysql_query('SELECT animal.numa AS numa, noma, nomp, prenomp FROM consultation, animal, proprietaire WHERE consultation.numa = animal.numa AND animal.nump = proprietaire.nump AND numv = '.$id);
			
			echo '<ul>';
			while($res = mysql_fetch_object($sql))
			{
				$numa = $res->numa;
				
				echo '<li>';
				echo $res->noma.' ('.$res->nomp.' '.$res->prenomp.')';
				
				$sql_cons = mysql_query('SELECT numc, date_format(datec, \'%d/%m/%Y\') AS datec,  heurec, prixc, numa FROM consultation WHERE numa = '.$numa.' AND numv = '.$id.' ORDER BY year(datec), month(datec), day(datec)');
				
				echo '<ul>';
				while($res_cons = mysql_fetch_object($sql_cons))
				{
					$numc = $res_cons->numc;
					
					echo '<li>';
					echo $res_cons->datec.' '.$res_cons->heurec.' ('.$res_cons->prixc.')';
					
					$sql_prat = mysql_query('SELECT noms FROM soin, pratiquer WHERE pratiquer.nums = soin.nums AND numc = '.$numc);
					
					echo '<br/><strong>Liste des soins :</strong>';
					echo '<ul>';
					while( $res_prat = mysql_fetch_object($sql_prat))
					{
						echo '<li>';
						echo $res_prat->noms;
						echo '</li>';
					}
					echo '</ul>';
					
					$sql_pres = mysql_query('SELECT nomm, posologie, duree FROM medicament, prescrire WHERE numc = '.$numc.' AND medicament.numm = prescrire.numm');
					
					if(mysql_num_rows($sql_pres) != 0)
					{
						echo '<br/><strong>Liste des prescriptions :</strong>';
						echo '<ul>';
						while( $res_pres = mysql_fetch_object($sql_pres))
						{
							echo '<li>';
							echo $res_pres->nomm.' (Posologie : '.$res_pres->posologie.' - Durée : '.$res_pres->duree;
							echo '</li>';
						}
						echo '</ul>';
					}					
					echo '</li>';
				}
				echo '</ul>';
				
				echo '</li>';
			}
			echo '</ul>';			
			
			echo '</div>'; // fermeture de la div text
			echo '</div>'; // fermeture de la div content
			
			require_once '../../utilities/footer.php';
		}
	}	
?>