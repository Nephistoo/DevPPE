﻿<?php

	require_once '../../utilities/secure.php';
	require_once '../../utilities/connect_db.php';
	
	if(!isset($_GET['action']))
	{
		header('Location: /veto/gestion/veterinaire/index.php');
	}
	else
	{
		$action = $_GET['action'];
		
		if($action == 'ajout' || ($action == 'modif' && isset($_GET['id'])))
		{				
			if($action == 'modif')
			{
				$id = $_GET['id'];
				$sql = mysql_query('SELECT numv FROM veterinaire WHERE numv = "'.$id.'"');
				$nb = mysql_num_rows($sql);
			}
			else
			{
				$id = ''; 
				$nb = 1;
			}
			
			if($nb == 0) // on vérifie si l'id existe bien dans la table
			{
				header('Location: /veto/gestion/veterinaire/index.php');
			}
			else
			{
				require_once '../../utilities/top.php';			
			
				echo '<div id="content">';
			
				if($action == 'ajout') {$text = 'Ajout';}else{$text = 'Modification';}
			
				echo '<h1>'.$text.' d\'un vétérinaire</h1>';
			
				echo '<div id="text">';
			
				if($action == 'modif') 
				{
					$sql = mysql_query('SELECT nomv, prenomv FROM veterinaire WHERE numv = '.$id);
					$res = mysql_fetch_object($sql);
					$nom = $res->nomv;
					$prenom = $res->prenomv;
				}
				else
				{
					$nom = '';
					$prenom = '';
				}
			
				echo '<form action="action_veto.php" method="POST">';
				echo '<input type="hidden" name="action" value="'.$action.'" />';
				echo '<input type="hidden" name="id" value="'.$id.'" />';
				echo '<table><tbody>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="nom">Nom du vétérinaire :</label></td>';
				echo '<td><input type="text" name="nom" value="'.$nom.'"/></td>';
				echo '</tr>';
				echo '<tr style="height: 40px">';
				echo '<td><label for="prenom">Prénom du vétérinaire :&nbsp;</label></td>';
				echo '<td><input type="text" name="prenom" value="'.$prenom.'" /></td>';
				echo '</tr>';
				
				echo '</tbody></table>';
				echo '<input type="submit" name="Valider" value="Valider"/>';
				echo '</form>';

				echo '</div>'; // fermeture de la div text

				echo '</div>'; // fermeture de la div content
				require_once '../../utilities/footer.php';
			}
		}
		else
		{
				header('Location: /veto/gestion/veterinaire/index.php');
		}
	}
?>