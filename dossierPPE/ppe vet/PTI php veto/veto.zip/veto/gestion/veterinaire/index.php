﻿<?php
	
	require_once '../../utilities/secure.php';
	require_once '../../utilities/top.php';
	
	echo '<div id="content">';
	echo '<h1>Gestion des vétérinaires</h1>';
	echo '<div id="text">';
	$sql = mysql_query('SELECT numv, nomv, prenomv FROM veterinaire');
	
	echo '<table id="liste"><tbody>';
	while($res = mysql_fetch_object($sql))
	{
		echo '<tr>';
		echo '<td id="libelle"><a href="veterinaire.php?id='.$res->numv.'">'.$res->nomv.' '.$res->prenomv.'</a></td>';
		echo '<td id="modif"><a href="gestion_veto.php?action=modif&id='.$res->numv.'">Modifier</a></td>';
		echo '<td id="supp"><a onclick="return(confirm(\' Etes-vous sûr de supprimer ce vétérinaire ?\'));" href="supp_veto.php?id='.$res->numv.'">Supprimer</a></td>';
		echo '</tr>';
	}
	
	echo '</tbody></table>';
	
	echo '<p><a href="gestion_veto.php?action=ajout">+ Ajouter</a></p>';
	echo '</div>'; // fermeture de la div text
	
	echo '</div>'; // fermeture de la div content
	
	require_once '../../utilities/footer.php';
?>