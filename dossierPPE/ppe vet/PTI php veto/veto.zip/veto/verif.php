<?php
	session_start();
	
	require_once 'utilities/connect_db.php';
	
	$valider = $_POST['Valider'];
	
	if($valider == 'Valider')
	{
		$login = $_POST['login'];
		$mdp = $_POST['mdp'];
		$mdp_crypt = md5($mdp);
		
		if($login == "" || $mdp == "")
		{
			header ('Location: /veto/index.php?erreur=incomplet');
		}
		else
		{
			$sql = mysql_query('SELECT id_user FROM t_user WHERE login = "'.$login.'" AND mdp = "'.$mdp_crypt.'"');
			$nb = mysql_num_rows($sql);
			
			if($nb == 0)
			{
				header ('Location: /veto/index.php?erreur=invalide');
			}
			else
			{
				session_regenerate_id();
				$_SESSION['login'] = $login;
				
				header ('Location: /veto/gestion/index.php');
			}
		}
		
	}

?>