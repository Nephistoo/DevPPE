﻿<?php
	session_destroy();
	header('Location: /veto/index.php');
?>