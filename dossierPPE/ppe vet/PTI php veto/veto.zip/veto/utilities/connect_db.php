﻿<?php
	$db = mysql_connect('localhost', 'root', '') or die('Erreur de connexion');
	mysql_select_db('veto',$db);
	mysql_query('SET NAMES UTF8');
?>