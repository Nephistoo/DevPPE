﻿<?php
	require_once 'header.php';
?>
	<body>
		<div id="general" class="home">