﻿<?php
	session_start();
	
	if($_SESSION['login'] == '')
	{
		header('Location: /veto/index.php');
	}

?>