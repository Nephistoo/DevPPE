﻿			<div id="footer">
				<p>Allô-Veto : Cabinet de vétérinaires
				<br />
				12, rue Feuteries 75016 Paris
				<br />
				01-47-96-15-32
				</p>
			</div>
		</div><!-- Fermeture de la div general-->
	</body>
</html>