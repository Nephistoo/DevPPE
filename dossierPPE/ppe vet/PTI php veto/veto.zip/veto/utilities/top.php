﻿<?php
	require_once 'header.php';
	require_once 'connect_db.php';
?>
	<body>
		<div id="general">
			<div id="top">
				<ul id="menu-top">
					<li><a href="/veto/gestion/index.php">Accueil</a></li>
					<li><a href="/veto/gestion/consultation/index.php">Consultation</a></li>
					<li><a href="/veto/gestion/proprietaire/index.php">Propriétaire</a></li>
					<li><a href="/veto/gestion/race/index.php">Race</a></li>
					<li><a href="/veto/gestion/medicament/index.php">Médicament</a></li>
				</ul>
				<p id="disconnect"><a href="/veto/utilities/disconnect.php">Déconnecter ?</a></p>
			</div>