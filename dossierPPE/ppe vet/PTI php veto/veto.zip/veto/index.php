<?php
	
	require_once 'utilities/top_home.php';
	
	echo '<div id="connexion">';
	
	echo '<p>Veuillez vous connecter :</p>';
	
	if(isset($_GET['erreur']))
	{
		if($_GET['erreur'] == 'incomplet')
		{
			echo '<p style="color:red;">Tous les champs sont obligatoires !</p>';
		}
		
		if($_GET['erreur'] == 'invalide')
		{
			echo '<p style="color:red;">Veuillez taper un login et un mot de passe valide !</p>';
		}
	}
	
	echo '<form id="connexion" name="connexion" action="verif.php" method="POST">';
	
	echo '<label for="login">Login : </label>';
	echo '<input type="text" name="login" id="login"/>';
	
	echo '<br />';
	
	echo '<label for="mdp">Mot de passe : </label>';
	echo '<input type="password" name="mdp" id="mdp"/>';

	echo '<br />';
	
	echo '<input type="submit" name="Valider" value="Valider"/>';
	
	echo '</form>';
	
	echo '</div>';

	require_once 'utilities/footer_home.php';
?>